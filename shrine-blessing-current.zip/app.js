const bucket = document.querySelector("#bucket");
const drawButton = document.querySelector("#drawButton");
const motionButton = document.querySelector("#motionButton");
const soundToggle = document.querySelector("#soundToggle");
const heroKicker = document.querySelector("#heroKicker");
const heroTitle = document.querySelector("#heroTitle");
const templeChooser = document.querySelector("#templeChooser");
const templeTrack = document.querySelector("#templeTrack");
const templePrev = document.querySelector("#templePrev");
const templeNext = document.querySelector("#templeNext");
const templeDots = document.querySelector("#templeDots");
const selectedTempleName = document.querySelector("#selectedTempleName");
const currentTempleTitle = document.querySelector("#currentTempleTitle");
const sceneVerticalSign = document.querySelector("#sceneVerticalSign");
const sceneRoot = document.querySelector(".scene");
const ritualArea = document.querySelector(".ritual-area");
const barrelAsset = document.querySelector("#barrelAsset");
const fallingStick = document.querySelector("#fallingStick");
const stickNumber = document.querySelector("#stickNumber");
const fortuneCard = document.querySelector("#fortuneCard");
const fortuneNo = document.querySelector("#fortuneNo");
const fortuneLevel = document.querySelector("#fortuneLevel");
const fortuneTitle = document.querySelector("#fortuneTitle");
const fortunePoem = document.querySelector("#fortunePoem");
const fortuneExplain = document.querySelector("#fortuneExplain");
const wishText = document.querySelector("#wishText");
const personText = document.querySelector("#personText");
const travelText = document.querySelector("#travelText");
const workText = document.querySelector("#workText");
const adviceText = document.querySelector("#adviceText");

const ASAKUSA_OMIKUJI_URL =
  "https://gist.githubusercontent.com/mmis1000/d94bb0a9f37cfd362453/raw/0e3a7b06688fd7950a8d5f1ae858b27be2be7e09/%E6%B7%BA%E8%8D%89%E7%B1%A4.json";
const titleSeeds = [
  "云开见月", "松风入袖", "灯火初明", "桥上春水", "竹影摇金",
  "远山有信", "晨钟醒梦", "花落成路", "白纸待书", "雨后新晴"
];
const poemSeeds = [
  "旧事如尘暂放手，新光一点在前头。慢行不失山门路，心定方知好处留。",
  "风从雷门过，人向愿中行。若把浮心歇，清泉自有声。",
  "一签落掌中，万念渐分明。急处宜收步，迟来反有成。",
  "灯影照归路，云边见晓霞。凡事凭诚意，春色入人家。",
  "浅草钟声远，纸签带晚香。守正能逢助，回头即是昌。"
];

const wishLines = [
  "可成，但需要耐心补足最后一步。",
  "先难后易，愿望会在稳定行动后靠近。",
  "不宜急求，换个方法更有转机。",
  "有贵人相助，记得主动开口。",
  "眼前未明，整理内心后再决定。"
];
const personLines = [
  "会来，但消息比预想稍晚。",
  "有人正在靠近，保持平常心。",
  "短期难遇，适合先照顾自己。",
  "旧识带来线索，别错过问候。",
  "缘分在路上，勿用猜疑催促。"
];
const travelLines = [
  "可行，越早规划越顺。",
  "途中有小波折，带齐证件与时间余量。",
  "暂缓为佳，改期反而更好。",
  "适合向东或近水之地。",
  "宜轻装，少贪多处。"
];
const workLines = [
  "稳中有进，适合完成旧项目。",
  "有新机会，但合同细节要看清。",
  "压力略重，先保质量再求速度。",
  "团队合作吉，独断则慢。",
  "学习新技能会打开局面。"
];
const adviceLines = [
  "这支签提醒你：好运不是催出来的，是在心稳、手稳之后自然出现的。",
  "今日宜把复杂的事情拆小，先做最能推动局面的那一步。",
  "别急着判断输赢，先把节奏调回来，答案会比情绪更可靠。",
  "适合求清晰，不适合求立刻。保持礼貌、诚意和边界。",
  "若遇阻滞，可换路而行；坚持本心，不必执着原来的形式。"
];

const levelPool = [
  ...Array(17).fill("大吉"),
  ...Array(35).fill("吉"),
  ...Array(5).fill("半吉"),
  ...Array(4).fill("小吉"),
  ...Array(3).fill("末小吉"),
  ...Array(6).fill("末吉"),
  ...Array(30).fill("凶"),
];
const levelByNumber = Array.from({ length: 100 }, (_, index) => {
  const slot = (index * 37 + 11) % 100;
  return levelPool[slot];
});

const localFortunes = Array.from({ length: 100 }, (_, index) => {
  const number = index + 1;
  const level = levelByNumber[index];
  const mood = level === "凶" ? "转念" : level.includes("吉") ? "顺势" : "守心";
  return {
    number,
    level,
    title: `${titleSeeds[index % titleSeeds.length]} · ${mood}`,
    poem: `${poemSeeds[index % poemSeeds.length]}（此为第 ${number} 签）`,
    explain: "本地离线签文；无需联网即可抽签。",
    wish: wishLines[(index + 1) % wishLines.length],
    person: personLines[(index + 2) % personLines.length],
    travel: travelLines[(index + 3) % travelLines.length],
    work: workLines[(index + 4) % workLines.length],
    advice: adviceLines[index % adviceLines.length],
  };
});
const asakusaFortunes = Array.isArray(window.ASAKUSA_FORTUNES) ? window.ASAKUSA_FORTUNES : localFortunes;
const kiyomizuFortunes = Array.isArray(window.KIYOMIZU_FORTUNES) ? window.KIYOMIZU_FORTUNES : asakusaFortunes;
const famousSourceConfigs = {
  fushimi_inari: {
    name: "伏见稻荷大社",
    title: "伏见稻荷御神签",
    advice: "稻荷信仰重在勤勉、商运与守护；此签宜看行动是否踏实，财运是否有根。",
  },
  meiji_jingu: {
    name: "明治神宫",
    title: "明治神宫御苑签",
    advice: "明治神宫以和歌御签闻名，重在自省与德行；此签宜从修身、敬意与日常选择中体会。",
  },
  todaiji: {
    name: "奈良东大寺",
    title: "东大寺大佛签",
    advice: "东大寺气象宏阔，此签宜以宽心、稳步和敬畏之念看待眼前事。",
  },
  naritasan: {
    name: "成田山新胜寺",
    title: "成田山不动明王签",
    advice: "新胜寺奉不动明王，此签重在破迷、决断与护持正念。",
  },
  kawasaki_daishi: {
    name: "川崎大师",
    title: "川崎大师厄除签",
    advice: "川崎大师以厄除闻名，此签宜看如何避凶、断旧习、稳住当下。",
  },
  tsurugaoka: {
    name: "鹤冈八幡宫",
    title: "鹤冈八幡宫胜运签",
    advice: "八幡信仰含守护与胜运，此签宜看勇气、节制和时机。",
  },
  izumo: {
    name: "出云大社",
    title: "出云大社缘结签",
    advice: "出云大社以缘结闻名，此签宜看人与人之间的诚意、距离和时机。",
  },
  dazaifu: {
    name: "太宰府天满宫",
    title: "太宰府天满宫学业签",
    advice: "天满宫奉菅原道真，此签宜看学业、考试、文书与长期积累。",
  },
  yasaka: {
    name: "八坂神社",
    title: "祇园八坂御神签",
    advice: "八坂神社与祇园祭、祓除疫厄相关；此签宜看净化、关系和身心秩序。",
  },
  shimogamo: {
    name: "下鸭神社",
    title: "下鸭神社水御签",
    advice: "下鸭神社有水占体验，此签宜看隐藏信息如何浮现，静待比强求更重要。",
  },
  hokkaido_jingu: {
    name: "札幌北海道神宫",
    title: "北海道神宫开拓签",
    advice: "北海道神宫守护北国开拓之地，此签宜看新的开始、耐寒的定力与长期积累。",
  },
  kinkakuji: {
    name: "金阁寺",
    title: "金阁寺金运签",
    advice: "金阁寺意象明亮，此签宜看光彩背后的克制、审美与财富观。",
  },
  ginkakuji: {
    name: "银阁寺",
    title: "银阁寺侘寂签",
    advice: "银阁寺气质清寂，此签宜看朴素、留白与内在秩序。",
  },
  tofukuji: {
    name: "东福寺",
    title: "东福寺禅意签",
    advice: "东福寺以禅境与枫景闻名，此签宜看放下执念后的转机。",
  },
};
const templeList = [
  {
    id: "sensoji",
    name: "浅草寺",
    region: "东京",
    themeColor: "#D04A4A",
    description: "东京最古老寺院",
    sceneSign: "雷门",
    cardImage: "./assets/mobile/card-sensoji.svg",
  },
  {
    id: "kiyomizu",
    name: "清水寺",
    sourceName: "京都清水寺",
    region: "京都",
    themeColor: "#C67A42",
    description: "京都名胜古迹",
    sceneSign: "清水寺",
    cardImage: "./assets/mobile/card-kiyomizu.svg",
  },
  {
    id: "meiji_jingu",
    name: "明治神宫",
    region: "东京",
    themeColor: "#4A6F52",
    description: "东京守护神宫",
    sceneSign: "明治神宫",
    cardImage: "./assets/mobile/card-meiji.svg",
  },
  {
    id: "hokkaido_jingu",
    name: "北海道神宫",
    region: "北海道",
    themeColor: "#5A76A5",
    description: "雪国中的祈愿",
    sceneSign: "北海道神宫",
    cardImage: "./assets/mobile/card-hokkaido.svg",
  },
];
let fortunes = asakusaFortunes;
let sourceName = "明治神宫";
let sourceValue = "meiji_jingu";
let selectedTempleIndex = templeList.findIndex((temple) => temple.id === sourceValue);
if (selectedTempleIndex < 0) selectedTempleIndex = 0;

let drawing = false;
let soundOn = true;
let audioContext;
let lastShakeTime = 0;
let dragStartX = 0;
let dragDistance = 0;
let loadingFortunes = false;

function onTempleChange(temple) {
  console.log("onTempleChange", temple);
}

function normalizeType(type) {
  return type === "兇" ? "凶" : type;
}

function getResult(result, keys, fallback = "签文未列出此项。") {
  for (const key of keys) {
    if (result && result[key]) return result[key].replaceAll("兇", "凶");
  }
  return fallback;
}

function normalizeRemoteFortune(item) {
  const result = item.result || {};
  return {
    number: Number(item.id),
    level: normalizeType(item.type),
    title: `浅草寺观音签 · 第 ${String(item.id).padStart(2, "0")} 签`,
    poem: item.poem,
    explain: item.explain,
    wish: getResult(result, ["願望"]),
    person: getResult(result, ["盼望的人"]),
    travel: getResult(result, ["旅行"]),
    work: getResult(result, ["交往", "結婚", "結親緣", "婚事", "嫁娶"]),
    advice: item.note || "以诚心行事，签意不只看吉凶，也看此刻可修正之处。",
  };
}

async function loadAsakusaFortunes() {
  try {
    const response = await fetch(ASAKUSA_OMIKUJI_URL, { cache: "force-cache" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data) || data.length < 100) throw new Error("fortune data incomplete");
    fortunes = data.map(normalizeRemoteFortune).sort((a, b) => a.number - b.number);
  } catch (error) {
    console.warn("浅草寺百签资料读取失败，使用本地兜底签文。", error);
  } finally {
    loadingFortunes = false;
    drawButton.disabled = false;
    bucket.disabled = false;
    drawButton.textContent = "摇一摇";
  }
}

function randomFortune() {
  return fortunes[Math.floor(Math.random() * fortunes.length)];
}

function makeTempleFortunes(config) {
  return asakusaFortunes.map((item) => ({
    ...item,
    title: `${config.title} · 第 ${String(item.number).padStart(2, "0")} 签`,
    advice: config.advice,
  }));
}

function setFortuneSource(source) {
  sourceValue = source;
  if (source === "local") {
    fortunes = localFortunes;
    sourceName = "本地灵签";
  } else if (source === "kiyomizu") {
    fortunes = kiyomizuFortunes;
    sourceName = "京都清水寺";
  } else if (famousSourceConfigs[source]) {
    fortunes = makeTempleFortunes(famousSourceConfigs[source]);
    sourceName = famousSourceConfigs[source].name;
  } else {
    fortunes = asakusaFortunes;
    sourceName = "浅草寺";
  }
  if (selectedTempleName) selectedTempleName.textContent = sourceName;
  if (heroKicker) heroKicker.textContent = sourceValue === "sensoji" ? "TOKYO ASAKUSA" : "OMIKUJI";
  if (heroTitle) heroTitle.textContent = "摇签祈福";
  const profile = templeList.find((temple) => temple.id === sourceValue) || templeList[0];
  selectedTempleIndex = templeList.findIndex((temple) => temple.id === profile.id);
  sceneRoot?.setAttribute("data-source", sourceValue);
  sceneRoot?.style.setProperty("--theme", profile.themeColor);
  if (currentTempleTitle) currentTempleTitle.textContent = `今日 · ${profile.name}`;
  if (sceneVerticalSign) sceneVerticalSign.textContent = profile.sceneSign || profile.name;
  updateTempleButtons();
  onTempleChange(profile);
  fortuneCard.hidden = true;
  fallingStick.classList.remove("is-visible");
  stickNumber.textContent = "--";
}

function buildTempleChooser() {
  if (!templeTrack) return;
  templeTrack.innerHTML = "";
  if (templeDots) templeDots.innerHTML = "";
  templeList.forEach((temple, index) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "temple-card";
    card.dataset.source = temple.id;
    card.dataset.index = String(index);
    card.style.setProperty("--card-theme", temple.themeColor);
    card.setAttribute("role", "listitem");
    card.innerHTML = `
      <strong>${temple.name}</strong>
      <img src="${temple.cardImage}" alt="" aria-hidden="true" />
      <span>${temple.description}</span>
    `;
    card.addEventListener("click", () => setFortuneSource(temple.id));
    templeTrack.appendChild(card);

    if (templeDots) {
      const dot = document.createElement("i");
      dot.dataset.index = String(index);
      templeDots.appendChild(dot);
    }
  });
  updateTempleButtons();
}

function moveTemple(step) {
  const nextIndex = (selectedTempleIndex + step + templeList.length) % templeList.length;
  setFortuneSource(templeList[nextIndex].id);
}

function updateTempleButtons() {
  templeTrack?.querySelectorAll(".temple-card").forEach((card) => {
    const index = Number(card.dataset.index);
    const distance = Math.abs(index - selectedTempleIndex);
    const wrappedDistance = Math.min(distance, templeList.length - distance);
    const isSelected = card.dataset.source === sourceValue;
    card.classList.toggle("is-selected", isSelected);
    card.classList.toggle("is-side", !isSelected && wrappedDistance === 1);
    card.classList.toggle("is-muted", wrappedDistance > 1);
    card.setAttribute("aria-pressed", String(isSelected));
    if (isSelected) {
      window.setTimeout(() => {
        card.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      }, 0);
    }
  });
  templeDots?.querySelectorAll("i").forEach((dot) => {
    dot.classList.toggle("is-active", Number(dot.dataset.index) === selectedTempleIndex);
  });
}

function populateStickCluster() {
  const cluster = bucket.querySelector(".stick-cluster3d");
  if (!cluster) return;
  const total = 44;
  cluster.innerHTML = "";
  for (let index = 0; index < total; index += 1) {
    const stick = document.createElement("i");
    const ring = index % 4;
    const row = Math.floor(index / 4);
    const angle = (index * 137.5 * Math.PI) / 180;
    const radiusX = 13 + ring * 13 + (row % 3) * 1.8;
    const radiusZ = -14 + ring * 10;
    const x = Math.cos(angle) * radiusX;
    const z = Math.sin(angle) * radiusZ;
    const rotation = Math.sin(angle) * 8;
    const height = 92 + ((index * 11) % 30);
    const scale = 0.84 + ring * 0.06;
    stick.style.setProperty("--stick-x", `${x.toFixed(1)}px`);
    stick.style.setProperty("--stick-z", `${z.toFixed(1)}px`);
    stick.style.setProperty("--stick-rot", `${rotation.toFixed(1)}deg`);
    stick.style.setProperty("--stick-height", `${height}px`);
    stick.style.setProperty("--stick-scale", scale.toFixed(2));
    stick.style.zIndex = String(100 + Math.round(z));
    cluster.appendChild(stick);
  }
}

function playTick() {
  if (!soundOn) return;
  const AudioEngine = window.AudioContext || window.webkitAudioContext;
  if (!AudioEngine) return;
  audioContext ||= new AudioEngine();
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(380, audioContext.currentTime);
  osc.frequency.exponentialRampToValueAtTime(760, audioContext.currentTime + 0.08);
  gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.16, audioContext.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.22);
  osc.connect(gain).connect(audioContext.destination);
  osc.start();
  osc.stop(audioContext.currentTime + 0.24);
}

function renderFortune(fortune) {
  fortuneNo.textContent = `第 ${String(fortune.number).padStart(2, "0")} 签`;
  fortuneLevel.textContent = fortune.level;
  fortuneTitle.textContent = `${sourceName} · ${fortune.title}`;
  fortunePoem.textContent = fortune.poem;
  fortuneExplain.textContent = fortune.explain;
  wishText.textContent = fortune.wish;
  personText.textContent = fortune.person;
  travelText.textContent = fortune.travel;
  workText.textContent = fortune.work;
  adviceText.textContent = fortune.advice;
  fortuneCard.hidden = false;
  fortuneCard.classList.remove("is-new");
  requestAnimationFrame(() => fortuneCard.classList.add("is-new"));
}

function drawFortune() {
  if (drawing || loadingFortunes) return;
  drawing = true;
  const fortune = randomFortune();
  stickNumber.textContent = `第${String(fortune.number).padStart(2, "0")}签`;
  ritualArea.classList.add("is-drawing");
  bucket.classList.remove("is-shaking");
  fallingStick.classList.remove("is-visible");
  if (barrelAsset) barrelAsset.src = "./assets/sticks3-sprites/fortune_barrel_idle.png";
  void bucket.offsetWidth;
  bucket.classList.add("is-shaking");
  fallingStick.classList.add("is-visible");
  window.omikujiAnimation?.shakeBucket?.(bucket, fallingStick);
  playTick();
  window.setTimeout(() => {
    if (barrelAsset) barrelAsset.src = "./assets/sticks3-sprites/fortune_barrel_out_3.png";
  }, 620);
  window.setTimeout(() => {
    if (barrelAsset) barrelAsset.src = "./assets/sticks3-sprites/fortune_barrel_result.png";
    renderFortune(fortune);
    ritualArea.classList.remove("is-drawing");
    drawing = false;
  }, 980);
}

async function enableMotion() {
  if (typeof DeviceMotionEvent !== "undefined" && typeof DeviceMotionEvent.requestPermission === "function") {
    const permission = await DeviceMotionEvent.requestPermission();
    if (permission !== "granted") return;
  }
  window.addEventListener("devicemotion", handleMotion, { passive: true });
  motionButton.textContent = "已开启摇一摇";
  motionButton.disabled = true;
}

function handleMotion(event) {
  const acc = event.accelerationIncludingGravity;
  if (!acc) return;
  const power = Math.abs(acc.x || 0) + Math.abs(acc.y || 0) + Math.abs(acc.z || 0);
  const now = Date.now();
  if (power > 28 && now - lastShakeTime > 1400) {
    lastShakeTime = now;
    drawFortune();
  }
}

bucket.addEventListener("click", drawFortune);
drawButton.addEventListener("click", drawFortune);
motionButton.addEventListener("click", enableMotion);
templePrev?.addEventListener("click", () => moveTemple(-1));
templeNext?.addEventListener("click", () => moveTemple(1));

soundToggle.addEventListener("click", () => {
  soundOn = !soundOn;
  soundToggle.classList.toggle("is-off", !soundOn);
});

bucket.addEventListener("pointerdown", (event) => {
  dragStartX = event.clientX;
  dragDistance = 0;
  bucket.setPointerCapture(event.pointerId);
});

bucket.addEventListener("pointermove", (event) => {
  if (!dragStartX) return;
  dragDistance = Math.max(dragDistance, Math.abs(event.clientX - dragStartX));
  const offset = Math.max(-18, Math.min(18, event.clientX - dragStartX));
  const rotation = Math.max(-8, Math.min(8, (event.clientX - dragStartX) / 3));
  bucket.style.transform = `translateX(calc(-50% + ${offset}px)) rotate(${rotation}deg)`;
});

bucket.addEventListener("pointerup", () => {
  bucket.style.transform = "";
  dragStartX = 0;
  if (dragDistance > 70) drawFortune();
});

drawButton.disabled = false;
bucket.disabled = false;
populateStickCluster();
buildTempleChooser();
setFortuneSource(sourceValue);
