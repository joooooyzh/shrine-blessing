import { writeFileSync } from "node:fs";
import { deflateSync } from "node:zlib";

const W = 64;
const H = 128;
const OUT = "assets/sticks3-sprites";

const C = {
  transparent: [0, 0, 0, 0],
  bg: "#F4E7C1",
  wood: "#A66A2F",
  hi: "#E6C38C",
  shadow: "#6B3D16",
  line: "#3A2A1A",
  plaque: "#7A4A20",
  text: "#F4D49A",
  glow: "#FBC02D",
};

function hex(hexValue, alpha = 255) {
  const value = Number.parseInt(hexValue.slice(1), 16);
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255, alpha];
}

function makeCanvas() {
  return new Uint8Array(W * H * 4);
}

function setPx(img, x, y, color) {
  if (x < 0 || y < 0 || x >= W || y >= H) return;
  const i = (y * W + x) * 4;
  img[i] = color[0];
  img[i + 1] = color[1];
  img[i + 2] = color[2];
  img[i + 3] = color[3];
}

function rect(img, x, y, w, h, color) {
  for (let yy = y; yy < y + h; yy += 1) {
    for (let xx = x; xx < x + w; xx += 1) setPx(img, xx, yy, color);
  }
}

function ellipse(img, cx, cy, rx, ry, color) {
  for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y += 1) {
    for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x += 1) {
      const dx = (x - cx) / rx;
      const dy = (y - cy) / ry;
      if (dx * dx + dy * dy <= 1) setPx(img, x, y, color);
    }
  }
}

function outlineRect(img, x, y, w, h, color) {
  rect(img, x, y, w, 1, color);
  rect(img, x, y + h - 1, w, 1, color);
  rect(img, x, y, 1, h, color);
  rect(img, x + w - 1, y, 1, h, color);
}

function line(img, x0, y0, x1, y1, color) {
  let dx = Math.abs(x1 - x0);
  let sx = x0 < x1 ? 1 : -1;
  let dy = -Math.abs(y1 - y0);
  let sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  while (true) {
    setPx(img, x0, y0, color);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) {
      err += dy;
      x0 += sx;
    }
    if (e2 <= dx) {
      err += dx;
      y0 += sy;
    }
  }
}

function drawGreekBand(img, x, y, w) {
  const lineC = hex(C.line);
  const shadow = hex(C.shadow);
  const hi = hex(C.hi);
  rect(img, x, y, w, 8, shadow);
  rect(img, x, y, w, 1, lineC);
  rect(img, x, y + 7, w, 1, lineC);
  for (let xx = x + 2; xx < x + w - 4; xx += 7) {
    rect(img, xx, y + 2, 5, 4, hi);
    rect(img, xx + 2, y + 4, 3, 1, shadow);
  }
}

function drawWoodGrain(img, x, y, w, h) {
  const hi = hex(C.hi, 160);
  const shadow = hex(C.shadow, 190);
  for (let xx = x + 4; xx < x + w - 3; xx += 5) line(img, xx, y + 2, xx - 2, y + h - 4, xx % 2 ? shadow : hi);
  line(img, x + 11, y + 14, x + 15, y + 22, shadow);
  line(img, x + w - 13, y + 30, x + w - 17, y + 42, shadow);
}

function drawStick(img, x, y, h, color = C.wood) {
  const c = hex(color);
  const lineC = hex(C.line);
  const hi = hex(C.hi);
  const shadow = hex(C.shadow);
  rect(img, x + 1, y, 5, h, c);
  rect(img, x + 2, y - 1, 3, 1, hi);
  rect(img, x, y + 2, 1, h - 4, lineC);
  rect(img, x + 6, y + 2, 1, h - 4, lineC);
  rect(img, x + 2, y + 2, 1, h - 4, hi);
  rect(img, x + 5, y + 3, 1, h - 6, shadow);
  setPx(img, x + 1, y + h - 1, lineC);
  setPx(img, x + 5, y + h - 1, lineC);
}

const glyphs = {
  "0": ["111", "101", "101", "101", "111"],
  "1": ["010", "110", "010", "010", "111"],
  "2": ["111", "001", "111", "100", "111"],
  "3": ["111", "001", "111", "001", "111"],
  "4": ["101", "101", "111", "001", "001"],
  "5": ["111", "100", "111", "001", "111"],
  "6": ["111", "100", "111", "101", "111"],
  "7": ["111", "001", "010", "010", "010"],
  "8": ["111", "101", "111", "101", "111"],
  "9": ["111", "101", "111", "001", "111"],
  "第": ["11111", "00100", "11111", "01010", "11111", "00100", "01110"],
  "签": ["11111", "01010", "11111", "00100", "11111", "01010", "11111"],
  "文": ["00100", "11111", "01010", "00100", "01010", "10001", "10001"],
  "筒": ["10101", "11111", "10001", "11111", "10101", "10101", "11111"],
};

function drawGlyph(img, ch, x, y, scale, color) {
  const g = glyphs[ch];
  if (!g) return 0;
  for (let yy = 0; yy < g.length; yy += 1) {
    for (let xx = 0; xx < g[yy].length; xx += 1) {
      if (g[yy][xx] === "1") rect(img, x + xx * scale, y + yy * scale, scale, scale, color);
    }
  }
  return g[0].length * scale;
}

function drawText(img, text, x, y, scale, color) {
  let cursor = x;
  for (const ch of text) {
    cursor += drawGlyph(img, ch, cursor, y, scale, color) + scale;
  }
}

function drawVerticalText(img, chars, cx, y, scale, color) {
  let yy = y;
  for (const ch of chars) {
    const width = glyphs[ch]?.[0].length * scale || 0;
    drawGlyph(img, ch, cx - Math.floor(width / 2), yy, scale, color);
    yy += 9 * scale;
  }
}

function drawBarrel(img, { out = 0, result = false } = {}) {
  const lineC = hex(C.line);
  const wood = hex(C.wood);
  const shadow = hex(C.shadow);
  const hi = hex(C.hi);
  const plaque = hex(C.plaque);
  const text = hex(C.text);
  const glow = hex(C.glow, 210);

  const bx = 4;
  const by = 48;
  const bw = 56;
  const bh = 78;
  const mouthY = 44;

  if (result) {
    ellipse(img, 32, 52, 23, 23, glow);
    for (const [x, y] of [[9, 31], [55, 32], [15, 19], [50, 67], [6, 74]]) {
      rect(img, x, y + 1, 5, 1, hex(C.glow));
      rect(img, x + 2, y - 1, 1, 5, hex(C.glow));
    }
  }

  for (let row = 0; row < 3; row += 1) {
    for (let col = 0; col < 8; col += 1) {
      const sx = bx + 5 + col * 6 + (row % 2) * 3;
      const sy = mouthY - 22 + row * 6 + ((col + row) % 2);
      drawStick(img, sx, sy, 38 - row * 3, col % 3 === 0 ? C.hi : C.wood);
    }
  }

  if (out > 0) drawFortuneStick(img, 32 - 8, 64 - out, result);

  rect(img, bx + 2, mouthY + 5, bw - 4, bh, wood);
  rect(img, bx + 4, mouthY + 10, bw - 8, bh - 10, wood);
  rect(img, bx, mouthY + 6, bw, 13, shadow);
  ellipse(img, bx + bw / 2, mouthY + 8, 25, 9, shadow);
  ellipse(img, bx + bw / 2, mouthY + 8, 20, 5, lineC);
  outlineRect(img, bx + 2, mouthY + 5, bw - 4, bh, lineC);
  drawWoodGrain(img, bx + 4, mouthY + 18, bw - 8, bh - 25);
  drawGreekBand(img, bx + 3, mouthY + 21, bw - 6);
  drawGreekBand(img, bx + 3, mouthY + bh - 9, bw - 6);

  rect(img, bx + 18, mouthY + 36, 20, 46, plaque);
  outlineRect(img, bx + 18, mouthY + 36, 20, 46, lineC);
  outlineRect(img, bx + 20, mouthY + 38, 16, 42, hi);
  drawVerticalText(img, "签文筒", bx + 28, mouthY + 41, 1, text);
  rect(img, bx + 24, mouthY + 80, 8, 4, text);
  setPx(img, bx + 23, mouthY + 81, text);
  setPx(img, bx + 32, mouthY + 81, text);
  ellipse(img, bx + bw / 2, mouthY + bh, 20, 5, shadow);
}

function drawFortuneStick(img, x, y, result = false) {
  const lineC = hex(C.line);
  const wood = hex(C.wood);
  const hi = hex(C.hi);
  const shadow = hex(C.shadow);
  rect(img, x + 2, y, 12, 72, wood);
  rect(img, x + 3, y - 1, 10, 2, hi);
  rect(img, x, y + 4, 2, 64, lineC);
  rect(img, x + 14, y + 4, 2, 64, lineC);
  rect(img, x + 4, y + 3, 2, 66, hi);
  rect(img, x + 12, y + 4, 2, 64, shadow);
  ellipse(img, x + 8, y + 10, 7, 7, hi);
  outlineRect(img, x + 3, y + 5, 11, 11, lineC);
  drawText(img, "第", x + 3, y + 1, 1, lineC);
  drawText(img, "28", x + 4, y + 8, 1, lineC);
  drawText(img, "签", x + 3, y + 17, 1, lineC);
  drawVerticalText(img, "签", x + 8, y + 38, 1, lineC);
  if (result) {
    setPx(img, x - 2, y + 31, lineC);
    setPx(img, x + 17, y + 31, lineC);
  }
}

function rotateNearest(src, degrees) {
  const dst = makeCanvas();
  const rad = (degrees * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  const cx = W / 2;
  const cy = 80;
  for (let y = 0; y < H; y += 1) {
    for (let x = 0; x < W; x += 1) {
      const dx = x - cx;
      const dy = y - cy;
      const sx = Math.round(cx + dx * cos + dy * sin);
      const sy = Math.round(cy - dx * sin + dy * cos);
      if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
      const si = (sy * W + sx) * 4;
      const di = (y * W + x) * 4;
      dst[di] = src[si];
      dst[di + 1] = src[si + 1];
      dst[di + 2] = src[si + 2];
      dst[di + 3] = src[si + 3];
    }
  }
  return dst;
}

function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i += 1) {
    c ^= buf[i];
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  return ~c >>> 0;
}

function chunk(type, data) {
  const typeBuf = Buffer.from(type);
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

function encodePng(img) {
  const raw = Buffer.alloc((W * 4 + 1) * H);
  for (let y = 0; y < H; y += 1) {
    raw[y * (W * 4 + 1)] = 0;
    Buffer.from(img.buffer, img.byteOffset + y * W * 4, W * 4).copy(raw, y * (W * 4 + 1) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(W, 0);
  ihdr.writeUInt32BE(H, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function save(name, img) {
  writeFileSync(`${OUT}/${name}.png`, encodePng(img));
}

const idle = makeCanvas();
drawBarrel(idle);
save("fortune_barrel_idle", idle);
save("fortune_barrel_left", rotateNearest(idle, -12));
save("fortune_barrel_right", rotateNearest(idle, 12));
save("fortune_barrel_left_max", rotateNearest(idle, -16));
save("fortune_barrel_right_max", rotateNearest(idle, 16));

for (const [i, out] of [0, 16, 32, 48].entries()) {
  const img = makeCanvas();
  drawBarrel(img, { out });
  save(`fortune_barrel_out_${i + 1}`, img);
}

const result = makeCanvas();
drawBarrel(result, { out: 48, result: true });
save("fortune_barrel_result", result);
