function animate(element, frames, options) {
  if (!element?.animate) return null;
  return element.animate(frames, options);
}

export function shakeBucket(bucket, fallingStick) {
  const tube = bucket.querySelector(".tube3d");
  const cluster = bucket.querySelector(".stick-cluster3d");
  const scene = bucket.querySelector(".bucket-scene3d");

  animate(tube, [
    { transform: "translate(-50%, -50%) rotateX(0deg) rotateZ(0deg)" },
    { transform: "translate(calc(-50% - 24px), -50%) rotateX(0deg) rotateZ(-5deg)" },
    { transform: "translate(calc(-50% + 26px), -50%) rotateX(0deg) rotateZ(5.5deg)" },
    { transform: "translate(calc(-50% - 22px), -50%) rotateX(0deg) rotateZ(-4.5deg)" },
    { transform: "translate(calc(-50% + 12px), -50%) rotateX(0deg) rotateZ(2.5deg)" },
    { transform: "translate(-50%, -50%) rotateX(0deg) rotateZ(0deg)" },
  ], {
    duration: 1050,
    easing: "cubic-bezier(.2,.86,.22,1)",
  });

  animate(cluster, [
    { transform: "translateX(-50%) translateZ(34px) translateY(0) rotateZ(0deg)" },
    { transform: "translateX(-50%) translateZ(34px) translateY(-16px) rotateZ(6deg)" },
    { transform: "translateX(-50%) translateZ(34px) translateY(7px) rotateZ(-7deg)" },
    { transform: "translateX(-50%) translateZ(34px) translateY(-8px) rotateZ(3deg)" },
    { transform: "translateX(-50%) translateZ(34px) translateY(0) rotateZ(0deg)" },
  ], {
    duration: 950,
    easing: "cubic-bezier(.2,.8,.2,1)",
  });

  animate(scene, [
    { filter: "blur(0px)" },
    { filter: "blur(1.6px)" },
    { filter: "blur(0px)" },
    { filter: "blur(1.2px)" },
    { filter: "blur(0px)" },
  ], {
    duration: 720,
    easing: "ease-in-out",
  });

  animate(fallingStick, [
    { opacity: 0, transform: "translate3d(-50%, 98%, 120px) scale(.72)" },
    { opacity: 1, transform: "translate3d(-50%, 48%, 120px) scale(.9)" },
    { opacity: 1, transform: "translate3d(-50%, 0%, 120px) scale(1)" },
  ], {
    duration: 1050,
    easing: "cubic-bezier(.2,.84,.3,1.12)",
    fill: "forwards",
  });
}
