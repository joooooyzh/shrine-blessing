(function () {
  function animate(element, frames, options) {
    if (!element || !element.animate) return null;
    return element.animate(frames, options);
  }

  const fallback = {
    shakeBucket(bucket, fallingStick) {
      const tube = bucket.querySelector(".tube3d");
      const cluster = bucket.querySelector(".stick-cluster3d");
      animate(tube, [
        { transform: "translate(-50%, -50%) rotateZ(0deg)" },
        { transform: "translate(calc(-50% - 20px), -50%) rotateZ(-4deg)" },
        { transform: "translate(calc(-50% + 20px), -50%) rotateZ(4deg)" },
        { transform: "translate(-50%, -50%) rotateZ(0deg)" },
      ], { duration: 900, easing: "cubic-bezier(.2,.86,.22,1)" });
      animate(cluster, [
        { transform: "translateX(-50%) translateZ(34px) translateY(0)" },
        { transform: "translateX(-50%) translateZ(34px) translateY(-14px)" },
        { transform: "translateX(-50%) translateZ(34px) translateY(0)" },
      ], { duration: 760, easing: "ease-out" });
      animate(fallingStick, [
        { opacity: 0, transform: "translate3d(-50%, 98%, 120px) scale(.72)" },
        { opacity: 1, transform: "translate3d(-50%, 0%, 120px) scale(1)" },
      ], { duration: 1050, easing: "cubic-bezier(.2,.84,.3,1.12)", fill: "forwards" });
    },
  };

  window.omikujiAnimation = window.omikuji3dPlugin || fallback;
})();
