#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

export PLATFORMIO_CORE_DIR="${PLATFORMIO_CORE_DIR:-$PWD/.platformio-core}"

if command -v pio >/dev/null 2>&1; then
  PIO_BIN="pio"
elif [ -x ".venv-pio/bin/pio" ]; then
  PIO_BIN=".venv-pio/bin/pio"
else
  echo "没有找到 PlatformIO。先运行一次 ./install_upload.sh"
  exit 1
fi

PORT="${1:-}"
if [ -z "$PORT" ]; then
  PORT="$(ls /dev/cu.usbmodem* /dev/cu.usbserial* /dev/cu.SLAB_USBtoUART* 2>/dev/null | head -n 1 || true)"
fi

if [ -z "$PORT" ]; then
  echo "没有检测到 StickS3 的 USB 串口。请插上设备，必要时按住中间键再点复位进入写入模式。"
  echo "当前可见串口："
  ls /dev/cu.* 2>/dev/null || true
  exit 1
fi

echo "使用串口：$PORT"
"$PIO_BIN" run -t upload --upload-port "$PORT"
