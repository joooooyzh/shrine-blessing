# StickS3 浅草寺摇签固件

这个目录是给 M5Stack StickS3 使用的 Arduino / PlatformIO 固件。

## 硬件交互

- 左右摇动 StickS3：抽签
- 首页 BtnA：切换寺庙
- 首页 BtnB：切换语言，顺序为中文 / 日本語 / English
- 出签后 BtnA：查看签文、翻页查看分项解读
- 出签后 BtnB：返回首页

屏幕会显示：

- 签号
- 吉凶：大吉、吉、半吉、小吉、末小吉、末吉、凶
- 签诗
- 解释
- 愿望、等待的人、旅行、交往
- 中文 / 日本語 / English 三种界面语言

## 离线运行

签文数据已经内置在固件里，不需要 Wi-Fi，烧录后可直接使用。

## 烧录

用 VS Code 打开 `firmware/sticks3`，安装 PlatformIO，然后执行 Upload。

依赖会由 PlatformIO 自动安装：

- M5Unified

也可以直接用终端：

```bash
cd "/Users/joy/Documents/抽签小应用/firmware/sticks3"
chmod +x install_upload.sh
./install_upload.sh
```

第一次跑 `install_upload.sh` 即可。之后只改代码、重新烧录时，用更快的：

```bash
chmod +x quick_upload.sh
./quick_upload.sh
```

脚本会优先复用系统里已有的 `pio`，没有才使用本目录里的 `.venv-pio/bin/pio`。

## 数据来源

内置签文整理自公开的浅草寺一百签资料：

https://gist.github.com/mmis1000/d94bb0a9f37cfd362453
