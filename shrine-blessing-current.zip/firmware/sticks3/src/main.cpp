#include <Arduino.h>
#include <M5Unified.h>

namespace {
constexpr int32_t kScreenW = 135;
constexpr int32_t kScreenH = 240;
constexpr int32_t kCenterX = kScreenW / 2;
constexpr uint32_t kShakeCooldownMs = 1800;
constexpr int32_t kBucketW = 64;
constexpr int32_t kBucketH = 96;
constexpr int32_t kFortuneStickW = 16;
constexpr int32_t kFortuneStickH = 72;
constexpr int32_t kButtonW = 100;
constexpr int32_t kButtonH = 24;

struct Fortune {
  uint8_t id;
  const char* type;
  const char* poem;
  const char* explain;
  const char* wish;
  const char* person;
  const char* travel;
  const char* relation;
};

struct FortuneSource {
  const char* name;
  const char* shortName;
  const char* title;
  const char* advice;
};

const Fortune fortunes[] = {
    {1, "大吉", "七宝浮图塔，高峰顶上安，众人皆仰望，莫作等闲看", "正道而行，众人相助，万事可望开朗。", "会充分实现。", "会出现。", "很好。", "很好。"},
    {2, "小吉", "月被浮云翳，立事自昏迷，幸乞阴公祐，何虑不开眉", "暂有迷雾，持续努力后可展眉。", "持续努力会实现。", "迟来。", "顺利。", "节制为好。"},
    {3, "凶", "愁恼损忠良，青宵一炷香，虽然防小过，闲虑觉时长", "多忧少成，宜守静等待时机。", "难实现。", "久等。", "不宜。", "节制。"},
    {4, "吉", "累有兴云志，君恩禄未封，若逢侯手印，好事始总总", "志向渐明，得人认可后好事接连。", "能实现。", "会出现。", "需忍耐。", "很好。"},
    {5, "凶", "家道未能昌，危危保祸殃，暗云侵月桂，佳人一炷香", "阻碍较多，凡事慎重。", "难实现。", "不会出现。", "慎重。", "慎重。"},
    {6, "末吉", "宅墓鬼凶多，人事有爻讹，伤财防损失，祈福始中和", "先损后稳，诚心修正可转和。", "难实现。", "迟来。", "尚可。", "不佳。"},
    {7, "凶", "登舟待便风，月色暗朦胧，欲辗香轮去，高山千万重", "风未至、路未开，暂守为宜。", "难实现。", "不会出现。", "不好。", "不好。"},
    {8, "大吉", "勿头中见尾，文华须得理，禾刀自偶然，当遇非常喜", "守正充实自己，自然得喜。", "会实现。", "会出现。", "注意细节。", "很好。"},
    {9, "大吉", "有名须得遇，三望一朝迁，贵人来指处，华果应时鲜", "贵人引路，愿望齐开。", "会实现。", "会出现。", "无碍。", "很好。"},
    {10, "大吉", "旧用多成破，新更始见财，改求云外望，枯木遭春开", "旧困消散，新机来到。", "会实现。", "会出现。", "很好。", "很好。"},
    {11, "大吉", "有禄兴家业，文华达帝都，云中乘好箭，兼得贵人扶", "才华受见，贵人扶助。", "充分实现。", "会出现。", "无碍。", "很好。"},
    {12, "大吉", "杨柳遇春时，残花发旧枝，重重霜雪里，黄金色更辉", "苦后逢春，旧枝生花。", "会实现。", "晚出现。", "无阻碍。", "适当。"},
    {13, "大吉", "手把大阳辉，东君发旧枝，稼苗方欲秀，犹更上云梯", "时机到来，努力可登高。", "会实现。", "会出现。", "春夏佳。", "很好。"},
    {14, "末吉", "玉石未分时，忧心转更悲，前途通大道，花发应残枝", "暂难分辨，忍耐后路通。", "费时可成。", "迟来。", "避开。", "暂缓。"},
    {15, "凶", "年乖数亦孤，久病未能苏，岸危舟未发，龙卧失明珠", "孤立受阻，宜保守。", "难实现。", "不会出现。", "不好。", "不好。"},
    {16, "吉", "破改重成望，前途喜亦宁，贵人相助处，禄马照前程", "换念有喜，贵人相助。", "能实现。", "会来。", "好。", "好。"},
    {17, "凶", "怪异防忧恼，人宅见分离，惜华还值雨，杯酒惹闲非", "烦恼易生，宜远纷争。", "难实现。", "不会出现。", "不佳。", "不佳。"},
    {18, "吉", "离暗出明时，麻衣变绿衣，旧忧终是退，遇禄应交辉", "离暗向明，旧忧渐退。", "会实现。", "会出现。", "好。", "好。"},
    {19, "末小吉", "家道生荆棘，儿孙防虎威，香前祈福厚，方得免分离", "阻碍在前，诚心可免分离。", "可成一半。", "迟来。", "节制。", "节制。"},
    {20, "吉", "月出渐分明，家财每每兴，何言先有滞，更变立功名", "月出渐明，阻滞转顺。", "能实现。", "会来。", "好。", "很好。"},
    {21, "吉", "洗出经年否，光华得再清，所求终吉利，重日照前程", "旧否洗去，前程复明。", "能实现。", "会出现。", "好。", "好。"},
    {22, "吉", "渐渐浓云散，看看月再明，逢春华果秀，雨过竹重青", "云散月明，雨过重青。", "可实现。", "会出现。", "好。", "好。"},
    {23, "凶", "红云随步起，一箭中青霄，鹿行千里远，争知去路遥", "前路远而不明，勿冒进。", "难实现。", "迟来。", "暂缓。", "谨慎。"},
    {24, "吉", "三女莫相逢，盟言说未通，门里心肝挂，缟素子重重", "纷扰中求清楚，守信可解。", "稍迟可成。", "迟来。", "慎重。", "谨慎。"},
    {25, "吉", "枯木逢春生，前途必利亨，亦得佳人箭，乘车禄自行", "枯木逢春，前途转亨。", "可实现。", "会来。", "好。", "好。"},
    {26, "吉", "将军有异声，进兵万里程，争知临敌处，道胜却虚名", "勇进须有谋，胜在正道。", "可实现。", "会来。", "好。", "好。"},
    {27, "吉", "望禄应重山，花红喜悦颜，举头看皎月，渐出黑云间", "云开见月，喜色渐来。", "可实现。", "会出现。", "好。", "好。"},
    {28, "凶", "意速无船渡，波深必误身，切须回旧路，方可免灾迍", "急进易失，回头可避灾。", "难实现。", "不会出现。", "不宜。", "节制。"},
    {29, "吉", "忧轗渐消融，求名得再通，宝财临禄位，当遇主人公", "忧消名通，财禄得位。", "可成。", "会来。", "好。", "好。"},
    {30, "半吉", "仙鹤立高枝，防他暗箭亏，井畔刚刀利，户内更防危", "吉中有险，防暗处疏忽。", "半成。", "迟来。", "谨慎。", "谨慎。"},
    {31, "末吉", "鲲鲸未变时，且守碧潭溪，风云兴巨浪，一息过天涯", "未到变时，守住根基。", "稍后可成。", "迟来。", "暂缓。", "守旧。"},
    {32, "吉", "似玉藏深石，休将故眼看，一朝良匠别，方见宝光寒", "珍宝待识，勿急求名。", "可成。", "会出现。", "好。", "好。"},
    {33, "吉", "枯木逢春艳，芳菲再发林，云间方见月，前遇贵人钦", "再发之象，贵人欣赏。", "可成。", "会来。", "好。", "好。"},
    {34, "吉", "腊木春将至，芳菲喜再新，鲲鲸兴巨浪，举钩禄为真", "春将至，旧事更新。", "能成。", "会来。", "好。", "好。"},
    {35, "吉", "射鹿须乘箭，故僧引路归，遇道同仙籍，光华映晚晖", "得引路人，晚景有光。", "可成。", "会出现。", "好。", "好。"},
    {36, "末吉", "先损后有益，如月之剥蚀，玉兔待重生，光华当满室", "先损后益，待月重圆。", "后成。", "迟来。", "暂缓。", "谨慎。"},
    {37, "半吉", "阴叆未能通，求名亦未逢，幸然须有变，一箭中双鸿", "未通之中有转机。", "半成。", "迟来。", "慎重。", "可期。"},
    {38, "凶", "月照天书静，云生雾彩霞，久想离庭客，无事惹咨嗟", "久念无益，勿自扰。", "难成。", "迟来。", "不好。", "谨慎。"},
    {39, "末吉", "望用方心腹，家乡被火灾，忧危三五度，由损断头财", "有忧损财，保守为宜。", "难成。", "迟来。", "慎重。", "谨慎。"},
    {40, "小吉", "中正方成道，奸邪恐惹愆，壶中盛妙药，非久去烦煎", "守中正，烦恼渐去。", "可成。", "会来。", "尚可。", "尚可。"},
    {41, "末吉", "有物不周旋，须防损半边，家乡烟火里，祈福始安然", "未周全，防半途损失。", "迟成。", "迟来。", "谨慎。", "谨慎。"},
    {42, "吉", "桂华春将到，云天好进程，贵人相遇处，暗月再分明", "贵人相遇，暗月复明。", "可成。", "会来。", "好。", "好。"},
    {43, "吉", "月桂将相满，追鹿映山溪，贵人乘远箭，好事始相宜", "渐满之象，好事相宜。", "可成。", "会来。", "好。", "好。"},
    {44, "吉", "盘中黑白子，一着要先机，天龙降甘泽，洗出旧根基", "把握先机，旧基更新。", "可成。", "会来。", "好。", "好。"},
    {45, "吉", "有意兴高显，禄马引前程，得遇云中箭，芝兰满路生", "前程有引，芝兰满路。", "会成。", "会来。", "好。", "好。"},
    {46, "凶", "雷发震天昏，佳人独掩门，交加文书上，无事也遭迍", "纷扰压身，无事亦生阻。", "难成。", "不来。", "不宜。", "不宜。"},
    {47, "吉", "更望身前立，何期在晚成，若遇重山去，财禄自然兴", "晚成之喜，财禄自兴。", "后成。", "迟来。", "好。", "好。"},
    {48, "小吉", "见禄隔前溪，劳心休更迷，一朝逢好渡，鸾凤入云飞", "隔溪见禄，待好渡口。", "可成。", "迟来。", "可行。", "可期。"},
    {49, "吉", "正好中秋月，蟾蜍皎洁间，暗云知何处，故故两相攀", "月明中秋，旧暗渐远。", "可成。", "会来。", "好。", "好。"},
    {50, "吉", "有达宜更变，重山利政逢，前途相偶合，财禄保亨通", "变化得利，财禄亨通。", "可成。", "会来。", "好。", "好。"},
    {51, "吉", "修进甚功辛，劳生未得时，腾身游碧汉，方得遇高枝", "辛苦修进，时至高飞。", "后成。", "迟来。", "尚可。", "好。"},
    {52, "凶", "有僭须惹讼，兼有事交加，门里防人危，灾临莫叹嗟", "是非交加，宜防争讼。", "难成。", "不来。", "不宜。", "谨慎。"},
    {53, "吉", "久困渐能安，云书降印权，残花终结实，时亨禄自迁", "久困渐安，残花结实。", "会成。", "会来。", "好。", "好。"},
    {54, "凶", "身同意不同，月蚀暗长空，轮虽常在手，鱼水未相逢", "心身不合，机会未逢。", "难成。", "不来。", "不宜。", "不宜。"},
    {55, "吉", "云散月重明，天书得志诚，虽然多阻滞，花发再重荣", "云散月明，花再重荣。", "可成。", "会来。", "好。", "好。"},
    {56, "末小吉", "生涯喜又忧，未老先白头，劳心千百度，芳遇贵人留", "喜忧相半，劳心后遇助。", "半成。", "迟来。", "谨慎。", "可期。"},
    {57, "吉", "欲渡长江阔，波深未自俦，前津逢浪静，重整钓鳌钩", "浪静再渡，整备后成。", "后成。", "迟来。", "稍后。", "好。"},
    {58, "凶", "有径江海隔，车行峻岭危，亦防多进退，犹恐小人亏", "路隔山危，防小人。", "难成。", "不来。", "不宜。", "谨慎。"},
    {59, "凶", "去住心无定，行藏亦未宁，一轮清皎洁，却被黑云乘", "心无定，明月被云。", "难成。", "迟来。", "暂缓。", "不佳。"},
    {60, "小吉", "高危安可涉，平坦是延年，守道当逢泰，风云不偶然", "避险守平，道正逢泰。", "可成。", "会来。", "平稳。", "尚可。"},
    {61, "半吉", "旧愆何日解，户内保婵娟，要逢十一口，遇鼠过牛边", "旧愆待解，机缘在细处。", "半成。", "迟来。", "慎重。", "谨慎。"},
    {62, "大吉", "灾轗时时退，名显四方扬，改故重乘禄，昴高福自昌", "灾退名扬，福禄自昌。", "会成。", "会来。", "很好。", "很好。"},
    {63, "凶", "何故生荆棘，佳人意渐疏，久困重轮下，黄金未出渠", "困在轮下，黄金未出。", "难成。", "不来。", "不宜。", "不佳。"},
    {64, "凶", "安居且虑危，情深主别离，风飘波浪急，鸳鸯各自飞", "安中有危，别离之象。", "难成。", "不来。", "不宜。", "慎重。"},
    {65, "末吉", "苦病兼防辱，乘危亦未稣，若见一阳后，方可作良图", "病辱须防，见阳后再图。", "后成。", "迟来。", "暂缓。", "谨慎。"},
    {66, "凶", "水滞少波涛，飞鸿落羽毛，重忧心绪乱，闲事惹风骚", "水滞羽落，勿惹闲事。", "难成。", "不来。", "不宜。", "不佳。"},
    {67, "凶", "枯木未生枝，独步上云岐，岂知身未稳，独自惹闲非", "根基未稳，独行生非。", "难成。", "不来。", "不宜。", "谨慎。"},
    {68, "吉", "异梦生英杰，前来事可疑，芳菲春日暖，依旧发残枝", "疑中有新，残枝再发。", "可成。", "会来。", "好。", "好。"},
    {69, "凶", "明月暗云浮，花红一半枯，惹事伤心处，行舟莫远图", "半枯之象，勿远图。", "难成。", "迟来。", "不宜。", "不佳。"},
    {70, "凶", "雷发庭前草，炎火向天飞，一心来赶禄，争奈掩朱扉", "火急求禄，门却未开。", "难成。", "不来。", "不宜。", "谨慎。"},
    {71, "凶", "道业未成时，何期两不宜，事烦心绪乱，翻做徘徊思", "事业未成，心乱徘徊。", "难成。", "迟来。", "不宜。", "不佳。"},
    {72, "吉", "户内防重厄，花果见分枝，严霜才过后，方可始相宜", "霜过之后，方可相宜。", "后成。", "迟来。", "稍后好。", "好。"},
    {73, "吉", "久暗渐分明，登江绿水澄，芝书从远降，终得异人成", "久暗转明，远方有信。", "可成。", "会来。", "好。", "好。"},
    {74, "凶", "蛇虎正交罗，牛生二尾多，交岁方成庆，上下不能和", "上下不和，须避冲突。", "难成。", "不来。", "不宜。", "谨慎。"},
    {75, "凶", "孤舟欲过岸，浪急渡人空，女人立流水，望月意情浓", "孤舟浪急，愿望落空。", "难成。", "不来。", "不宜。", "不佳。"},
    {76, "吉", "富贵天之佑，何须苦用心，前程应显迹，久用得高临", "天佑渐显，久用得高。", "可成。", "会来。", "好。", "好。"},
    {77, "吉", "累滞未能苏，求名莫远图，登舟波浪急，咫尺隔天衢", "近处求稳，勿远图。", "可成。", "迟来。", "慎重。", "尚可。"},
    {78, "大吉", "但存公道正，何愁理去忠，松柏苍苍翠，前山禄马重", "公道正直，禄马重来。", "会成。", "会来。", "很好。", "很好。"},
    {79, "吉", "残月未还光，樽前非语伤，户中有人厄，祈福保青阳", "残月待圆，祈福保安。", "后成。", "迟来。", "暂缓。", "谨慎。"},
    {80, "大吉", "深山多养道，忠正帝王宣，凤遂鸾飞去，升高过九天", "忠正高升，凤鸾飞天。", "会成。", "会来。", "很好。", "很好。"},
    {81, "小吉", "道合须成合，先忧事更多，所求财宝盛，更变得中和", "先忧后和，求财有望。", "可成。", "迟来。", "尚可。", "尚可。"},
    {82, "凶", "火发应连天，新愁惹旧愆，欲求千里外，要渡更无船", "新旧愁连，远求无船。", "难成。", "不来。", "不宜。", "不佳。"},
    {83, "凶", "举步出云端，高枝未可攀，升头看皎月，犹在黑云间", "高枝未攀，月在云中。", "难成。", "迟来。", "不宜。", "谨慎。"},
    {84, "凶", "否极方无泰，花开值晚秋，人情不调备，财宝鬼来偷", "否未转泰，防失财。", "难成。", "不来。", "不宜。", "谨慎。"},
    {85, "吉", "望用何愁晚，求名渐得宁，云梯终有望，归路入蓬瀛", "晚望无妨，云梯有路。", "可成。", "会来。", "好。", "好。"},
    {86, "大吉", "花发应阳台，车行进宝财，执文朝帝殿，走马听声雷", "花发进财，声名可达。", "会成。", "会来。", "很好。", "很好。"},
    {87, "大吉", "凿石方逢玉，淘沙始见金，青霄终有路，只恐不坚心", "淘沙见金，贵在坚心。", "会成。", "会来。", "很好。", "很好。"},
    {88, "凶", "作事不和同，临危更主凶，佳人生苦根，闲虑两三重", "不和生凶，勿强作。", "难成。", "不来。", "不宜。", "不佳。"},
    {89, "大吉", "一片无瑕玉，从今好琢磨，得遇高人识，方逢喜气多", "美玉待琢，高人识之。", "会成。", "会来。", "很好。", "很好。"},
    {90, "大吉", "一信向天飞，秦川舟自归，前途成好事，应得贵人推", "信达天听，贵人推动。", "会成。", "会来。", "很好。", "很好。"},
    {91, "吉", "改革前途去，月桂又逢圆，云中乘禄至，凡事可宜先", "改革向前，月桂复圆。", "可成。", "会来。", "好。", "好。"},
    {92, "吉", "自幼常为旅，逢春骏马骄，前程宜进步，得箭降青霄", "骏马逢春，宜进步。", "可成。", "会来。", "好。", "好。"},
    {93, "吉", "有鱼临旱地，跳跃入波涛，隔中须有望，先且虑尘劳", "旱鱼入波，先劳后望。", "可成。", "迟来。", "好。", "尚可。"},
    {94, "半吉", "事忌樽前语，人防小辈交，幸乞阴公祐，方免事敌爻", "言语需慎，防小人。", "半成。", "迟来。", "慎重。", "谨慎。"},
    {95, "吉", "志气勤修业，禄位未造逢，若闻金鸡语，乘船得便风", "勤修待机，便风将至。", "后成。", "会来。", "好。", "好。"},
    {96, "大吉", "鸡逐凤同飞，高林整羽仪，棹舟须济岸，宝货满船归", "凤鸡同飞，满载而归。", "会成。", "会来。", "很好。", "很好。"},
    {97, "凶", "雾罩重楼屋，佳人水上行，白云归去路，不见月波澄", "雾重路迷，勿妄动。", "难成。", "不来。", "不宜。", "不佳。"},
    {98, "凶", "欲理新丝乱，闲愁足是非，只困罗网里，相见几人悲", "乱丝难理，是非缠身。", "难成。", "不来。", "不宜。", "谨慎。"},
    {99, "大吉", "红日当门照，暗月再重圆，遇珍须得宝，颇有称心田", "红日照门，暗月重圆。", "会成。", "会来。", "很好。", "很好。"},
    {100, "凶", "禄走白云间，携琴走远山，不遇神仙面，空惹意阑珊", "求禄远走，暂难遇合。", "难成。", "迟来。", "暂缓。", "谨慎。"},
};
constexpr uint8_t kFortuneCount = sizeof(fortunes) / sizeof(fortunes[0]);
const FortuneSource sources[] = {
    {"浅草寺", "浅草寺", "浅草寺观音签", "浅草寺观音百签，重在读懂吉凶背后的提醒。"},
    {"京都清水寺", "清水寺", "清水寺御神签", "清水寺御神签多用古语诗意，宜静心细读。"},
    {"伏见稻荷", "伏见稻荷", "伏见稻荷御神签", "稻荷信仰重勤勉与商运，宜看行动是否踏实。"},
    {"明治神宫", "明治神宫", "明治神宫御苑签", "明治神宫重和歌与修身，宜从德行中体会。"},
    {"奈良东大寺", "东大寺", "东大寺大佛签", "东大寺气象宏阔，宜宽心稳步。"},
    {"成田山", "成田山", "成田山不动签", "不动明王重破迷与决断，宜护持正念。"},
    {"川崎大师", "川崎大师", "川崎大师厄除签", "厄除之签重在避凶、断旧习。"},
    {"鹤冈八幡宫", "鹤冈八幡", "鹤冈八幡胜运签", "八幡信仰含守护与胜运，宜看勇气与时机。"},
    {"出云大社", "出云大社", "出云大社缘结签", "出云以缘结闻名，宜看诚意、距离和时机。"},
    {"太宰府天满宫", "太宰府", "太宰府学业签", "天满宫重学业文书，宜看长期积累。"},
    {"八坂神社", "八坂神社", "祇园八坂御神签", "八坂重祓除疫厄，宜看身心秩序。"},
    {"下鸭神社", "下鸭神社", "下鸭神社水御签", "水御签重显现与等待，静待比强求更重要。"},
    {"札幌北海道神宫", "北海道神宫", "北海道神宫开拓签", "北海道神宫守护北国开拓之地，宜看新的开始与定力。"},
    {"金阁寺", "金阁寺", "金阁寺金运签", "金阁意象明亮，宜看光彩背后的克制。"},
    {"银阁寺", "银阁寺", "银阁寺侘寂签", "银阁气质清寂，宜看朴素与留白。"},
    {"东福寺", "东福寺", "东福寺禅意签", "东福寺禅境清深，宜看放下后的转机。"},
};
constexpr uint8_t kSourceCount = sizeof(sources) / sizeof(sources[0]);
uint8_t currentSource = 0;
enum class Language : uint8_t { Zh, Ja, En };
Language currentLanguage = Language::Zh;
uint8_t currentIndex = 0;
uint8_t page = 0;
enum class ScreenState : uint8_t { Home, ReadyToReveal, Poem, Detail };
ScreenState screen = ScreenState::Home;
uint8_t pendingIndex = 0;
uint32_t lastDrawMs = 0;
float lastAx = 0.0f;
float lastAy = 0.0f;
float lastAz = 0.0f;

uint16_t paper = 0xf718;      // #F4E7C1
uint16_t card = 0xffdd;       // #FFF8E8
uint16_t ink = 0x3943;        // #3A2A1A
uint16_t red = 0xb1c7;        // #B33A3A
uint16_t gold = 0xe611;       // #E6C38C
uint16_t night = 0x28c6;      // #2F3130
uint16_t wood = 0xa345;       // #A66A2F
uint16_t woodDark = 0x69c2;   // #6B3D16
uint16_t woodLight = 0xe611;  // #E6C38C
uint16_t blue = 0x299b;       // #2A65D8
uint16_t buttonGold = 0xdd07; // #DFA23A
uint16_t plaque = 0x7a44;     // #7A4A20
uint16_t textGold = 0xf693;   // #F4D49A
uint16_t footer = 0xffdd;     // #FFF8E8
uint16_t daikichiColor = 0xd0a5;  // #D32F2F
uint16_t chukichiColor = 0xf1e0;  // #F57C00
uint16_t kichiColor = 0xfb05;     // #FBC02D
uint16_t suekichiColor = 0x89ac;  // #8D6E63
uint16_t badColor = 0x51af;       // #546E7A

bool isJa() { return currentLanguage == Language::Ja; }
bool isEn() { return currentLanguage == Language::En; }

void applyLanguageFont() {
  if (isJa()) {
    M5.Display.setFont(&fonts::efontJA_12);
  } else {
    M5.Display.setFont(&fonts::efontCN_12);
  }
}

const char* languageCode() {
  if (isJa()) return "JP";
  if (isEn()) return "EN";
  return "CN";
}

const char* sourceShortName() {
  if (isEn()) {
    static constexpr const char* names[] = {
        "Sensoji", "Kiyomizu", "Fushimi", "Meiji", "Todaiji", "Naritasan",
        "Kawasaki", "Hachimangu", "Izumo", "Dazaifu", "Yasaka", "Shimogamo",
        "Hokkaido", "Kinkakuji", "Ginkakuji", "Tofukuji"};
    return names[currentSource % kSourceCount];
  }
  if (isJa()) {
    static constexpr const char* names[] = {
        "浅草寺", "清水寺", "伏見稲荷", "明治神宮", "東大寺", "成田山",
        "川崎大師", "鶴岡八幡", "出雲大社", "太宰府", "八坂神社", "下鴨神社",
        "北海道神宮", "金閣寺", "銀閣寺", "東福寺"};
    return names[currentSource % kSourceCount];
  }
  return sources[currentSource].shortName;
}

String fortuneTypeLabel(const char* type) {
  String t(type);
  if (isEn()) {
    if (t == "大吉") return "GREAT";
    if (t == "吉") return "GOOD";
    if (t == "半吉") return "HALF";
    if (t == "小吉") return "SMALL";
    if (t == "末小吉") return "LATE+";
    if (t == "末吉") return "LATE";
    return "BAD";
  }
  if (isJa()) {
    if (t == "凶") return "凶";
    return t;
  }
  return t;
}

const char* labelTodayLuck() {
  if (isEn()) return "TODAY";
  if (isJa()) return "今日の運勢";
  return "今日运势";
}

const char* labelShake() {
  if (isEn()) return "SHAKE";
  if (isJa()) return "振 る";
  return "摇 一 摇";
}

const char* labelShaking() {
  if (isEn()) return "Shaking";
  if (isJa()) return "祈願中";
  return "摇动中";
}

const char* labelNextPage() {
  if (isEn()) return "▼ NEXT";
  if (isJa()) return "▼ 次へ";
  return "▼ 下一页";
}

const char* labelDetail() {
  if (isEn()) return "▼ DETAILS";
  if (isJa()) return "▼ 詳細";
  return "▼ 查看详情";
}

const char* labelReveal() {
  if (isEn()) return "A REVEAL";
  if (isJa()) return "A 開く";
  return "A 查看签文";
}

const char* labelActToday() {
  if (isEn()) return "Act today";
  if (isJa()) return "今日は一歩";
  return "今日宜行动";
}

String fortuneNoText(uint8_t id) {
  if (isEn()) return "No. " + String(id);
  if (isJa()) return "第 " + String(id) + " 番";
  return "第 " + String(id) + " 签";
}

String poemTitle(uint8_t id) {
  if (isEn()) return "No." + String(id) + " Poem";
  if (isJa()) return "第" + String(id) + "番・御詠";
  return "第" + String(id) + "签·签诗";
}

const char* readingTitle() {
  if (isEn()) return "Reading";
  if (isJa()) return "解  説";
  return "解  签";
}

const char* workTitle() {
  if (isEn()) return "Work";
  if (isJa()) return "仕事運";
  return "事业运";
}

const char* moneyTitle() {
  if (isEn()) return "Money";
  if (isJa()) return "金  運";
  return "财运";
}

const char* loveTitle() {
  if (isEn()) return "Love";
  if (isJa()) return "恋  愛";
  return "感情";
}

const char* overviewTitle() {
  if (isEn()) return "Overview";
  if (isJa()) return "運勢一覧";
  return "运势总览";
}

const char* overviewLabel(uint8_t row) {
  if (isEn()) {
    static constexpr const char* labels[] = {"Work", "Money", "Love", "Health", "Travel"};
    return labels[row % 5];
  }
  if (isJa()) {
    static constexpr const char* labels[] = {"仕事", "金運", "恋愛", "健康", "旅行"};
    return labels[row % 5];
  }
  static constexpr const char* labels[] = {"事业", "财运", "感情", "健康", "出行"};
  return labels[row % 5];
}

String levelSummary(const char* type);

String localizedPoem(const Fortune& f) {
  if (!isEn() && !isJa()) return String(f.poem);
  String t(f.type);
  if (isEn()) {
    if (t == "大吉") return "A bright sign. Keep a sincere heart; help and good timing are near.";
    if (t == "凶") return "Move slowly. Avoid haste, protect your peace, and return to the safe path.";
    if (t.indexOf("末") >= 0) return "The beginning is slow, but patience will open a better road.";
    return "Stay steady and kind. Small efforts will gather into good fortune.";
  }
  if (t == "大吉") return "心を正しく保てば、助けと良き時が近づきます。";
  if (t == "凶") return "急がず、無理を避け、静かに安全な道へ戻りましょう。";
  if (t.indexOf("末") >= 0) return "初めは滞りますが、忍耐の後に道が開けます。";
  return "落ち着いて誠を尽くせば、小さな努力が福を呼びます。";
}

String localizedExplain(const Fortune& f) {
  if (!isEn() && !isJa()) return String(f.explain);
  String t(f.type);
  if (isEn()) {
    if (t == "大吉") return "Excellent luck. Begin with confidence and keep gratitude in your actions.";
    if (t == "凶") return "Risk is high. Do not force the matter; simplify plans and wait for clarity.";
    if (t.indexOf("末") >= 0) return "Things improve later. First clear small problems, then move forward.";
    return "Good but gradual. Keep a steady rhythm and listen to helpful advice.";
  }
  if (t == "大吉") return "大きな吉運です。感謝を忘れず、自信を持って進みましょう。";
  if (t == "凶") return "無理は禁物です。計画を小さくし、明るくなる時を待ちましょう。";
  if (t.indexOf("末") >= 0) return "後に良くなる運です。まず小さな不安を整えましょう。";
  return "穏やかな吉運です。焦らず、助言を聞いて進みましょう。";
}

String localizedDetail(const Fortune& f, uint8_t pageNo) {
  if (!isEn() && !isJa()) {
    if (pageNo == 3) return String(f.relation);
    if (pageNo == 4) return String(f.wish);
    return String(f.person);
  }
  String t(f.type);
  bool bad = t == "凶";
  bool great = t == "大吉";
  if (isEn()) {
    if (pageNo == 3) return bad ? "Work: avoid risky choices. Finish what is already in your hands." : great ? "Work: strong support appears. Take the lead with care." : "Work: steady progress. Teamwork brings better results.";
    if (pageNo == 4) return bad ? "Money: keep spending low and avoid speculation." : great ? "Money: a good chance arrives. Stay practical." : "Money: small gains build up. Do not rush.";
    return bad ? "Love: speak gently and do not force an answer." : great ? "Love: warm connection grows through sincerity." : "Love: patience and clear words help the bond.";
  }
  if (pageNo == 3) return bad ? "仕事：危ない判断を避け、手元のことを丁寧に。" : great ? "仕事：助けが強く現れます。丁寧に主導しましょう。" : "仕事：着実に進みます。協力が吉です。";
  if (pageNo == 4) return bad ? "金運：出費を抑え、投機は避けましょう。" : great ? "金運：良い機会あり。現実的に受け取りましょう。" : "金運：小さな積み重ねが実ります。";
  return bad ? "恋愛：やさしく話し、答えを急がないこと。" : great ? "恋愛：誠意から温かな縁が育ちます。" : "恋愛：待つ心と素直な言葉が助けます。";
}

uint16_t fortuneLevelColor(const char* type) {
  String t(type);
  if (t == "大吉") return daikichiColor;
  if (t == "吉") return kichiColor;
  if (t == "半吉" || t == "小吉") return chukichiColor;
  if (t.indexOf("末") >= 0) return suekichiColor;
  return badColor;
}

void tickSound(uint16_t frequency = 980, uint32_t duration = 28) {
  M5.Speaker.tone(frequency, duration, 0, true);
}

void bucketRattleSound(uint8_t step) {
  static constexpr uint16_t tones[] = {360, 430, 520, 610, 760};
  uint16_t frequency = tones[(step * 3 + random(0, 5)) % 5];
  uint32_t duration = 12 + random(0, 18);
  M5.Speaker.tone(frequency, duration, 0, true);
  if ((step % 3) == 1) {
    delay(16);
    M5.Speaker.tone(tones[random(0, 4)], 10 + random(0, 12), 1, true);
  }
}

void revealSound() {
  M5.Speaker.tone(520, 34, 0, true);
  delay(42);
  M5.Speaker.tone(330, 72, 0, true);
}

void setupSpeaker() {
  M5.Speaker.begin();
  M5.Speaker.setVolume(255);
  M5.Speaker.setAllChannelVolume(255);
  tickSound(880, 120);
  delay(150);
  tickSound(1320, 120);
}

void drawWrapped(const String& text, int32_t x, int32_t y, int32_t w, int32_t lineHeight, uint16_t color) {
  M5.Display.setTextColor(color);
  int32_t cursorX = x;
  int32_t cursorY = y;
  String token;
  for (uint32_t i = 0; i < text.length();) {
    uint8_t c = text[i];
    uint8_t step = 1;
    if ((c & 0x80) == 0x00) step = 1;
    else if ((c & 0xE0) == 0xC0) step = 2;
    else if ((c & 0xF0) == 0xE0) step = 3;
    else if ((c & 0xF8) == 0xF0) step = 4;
    uint32_t end = i + step;
    if (end > text.length()) end = text.length();
    token = text.substring(i, end);
    if (token == "\n") {
      cursorX = x;
      cursorY += lineHeight;
      i = end;
      continue;
    }
    int32_t tw = M5.Display.textWidth(token);
    if (cursorX + tw > x + w) {
      cursorX = x;
      cursorY += lineHeight;
      if (cursorY > 232) return;
    }
    M5.Display.drawString(token, cursorX, cursorY);
    cursorX += tw;
    i += step;
  }
}

void resetShakeBaseline() {
  if (!M5.Imu.update()) return;
  auto imu = M5.Imu.getImuData();
  lastAx = imu.accel.x;
  lastAy = imu.accel.y;
  lastAz = imu.accel.z;
}

void drawWoodGrain(int x, int y, int w, int h, int offset) {
  for (int i = 0; i < w; i += 7) {
    int gx = x + i + (offset % 3);
    uint16_t c = (i % 14 == 0) ? 0x7924 : 0xbb06;
    M5.Display.drawFastVLine(gx, y + 3, h - 6, c);
  }
  for (int i = 0; i < 6; ++i) {
    int gx = x + 8 + i * 9 + (offset % 4);
    M5.Display.drawLine(gx, y + 12, gx - 3, y + h - 12, (i % 2) ? woodDark : 0xb246);
  }
}

void drawGreekBand(int x, int y, int w) {
  M5.Display.fillRect(x, y, w, 10, woodDark);
  M5.Display.drawFastHLine(x, y, w, ink);
  M5.Display.drawFastHLine(x, y + 9, w, ink);
  M5.Display.drawFastHLine(x, y + 1, w, gold);
  M5.Display.drawFastHLine(x, y + 8, w, gold);
  for (int i = x + 3; i < x + w - 6; i += 10) {
    M5.Display.drawRect(i, y + 3, 7, 5, gold);
    M5.Display.drawFastHLine(i + 3, y + 5, 4, woodDark);
  }
}

void drawPixelStick(int x, int y, int h, uint16_t c) {
  M5.Display.fillRoundRect(x, y, 7, h, 3, c);
  M5.Display.drawRoundRect(x, y, 7, h, 3, ink);
  M5.Display.drawFastVLine(x + 2, y + 3, h - 6, woodLight);
  M5.Display.drawFastVLine(x + 6, y + 4, h - 8, woodDark);
  M5.Display.fillRect(x + 2, y - 1, 3, 2, gold);
}

void drawBucketSealText(int cx, int y) {
  M5.Display.setTextColor(textGold);
  M5.Display.setTextSize(1);
  if (isEn()) {
    M5.Display.drawCenterString("OMI", cx, y);
    M5.Display.drawCenterString("KU", cx, y + 15);
    M5.Display.drawCenterString("JI", cx, y + 30);
    return;
  }
  if (isJa()) {
    M5.Display.drawCenterString("御", cx, y);
    M5.Display.drawCenterString("神", cx, y + 15);
    M5.Display.drawCenterString("籤", cx, y + 30);
    return;
  }
  M5.Display.drawCenterString("签", cx, y);
  M5.Display.drawCenterString("文", cx, y + 15);
  M5.Display.drawCenterString("筒", cx, y + 30);
}

void drawFortuneBucket(int offset = 0, bool shaking = false) {
  M5.Display.fillScreen(paper);
  M5.Display.fillRect(0, 0, kScreenW, kScreenH, paper);
  M5.Display.drawFastVLine(13, 59, 75, 0xef15);
  M5.Display.drawFastVLine(120, 56, 84, 0xef15);
  M5.Display.fillRect(12, 132, 18, 3, 0xef15);
  M5.Display.fillRect(108, 140, 16, 3, 0xef15);
  M5.Display.fillEllipse(kCenterX, 198, 35, 7, 0xd6cb);

  if (shaking) {
    M5.Display.drawFastVLine(14, 92, 26, woodLight);
    M5.Display.drawFastVLine(18, 86, 20, woodLight);
    M5.Display.drawFastVLine(117, 93, 26, woodLight);
    M5.Display.drawFastVLine(113, 108, 20, woodLight);
  }

  int bx = (kScreenW - kBucketW) / 2 + offset;
  int by = 98;
  int bw = kBucketW;
  int bh = kBucketH;
  int mouthY = by + 12;

  for (int row = 0; row < 2; ++row) {
    for (int col = 0; col < 8; ++col) {
      int sx = bx + 5 + col * 7 + (row % 2) * 3;
      int sy = by - 18 + row * 6 + ((col + row) % 2);
      if (sx > bx + bw - 8) continue;
      drawPixelStick(sx, sy, 34 - row * 4, (col + row) % 3 == 0 ? woodLight : wood);
    }
  }

  M5.Display.fillRect(bx - 2, mouthY - 5, bw + 4, 18, woodDark);
  M5.Display.drawRect(bx - 2, mouthY - 5, bw + 4, 18, ink);
  M5.Display.fillRect(bx + 5, mouthY + 1, bw - 10, 7, woodLight);
  M5.Display.fillRect(bx + 11, mouthY + 4, bw - 22, 5, ink);

  M5.Display.fillRect(bx, mouthY + 6, bw, bh - 15, wood);
  M5.Display.drawRect(bx, mouthY + 6, bw, bh - 15, ink);
  M5.Display.fillRect(bx + 3, mouthY + 14, bw - 6, bh - 31, wood);
  drawWoodGrain(bx + 3, mouthY + 11, bw - 6, bh - 24, offset);

  drawGreekBand(bx + 2, mouthY + 16, bw - 4);
  drawGreekBand(bx + 2, mouthY + bh - 29, bw - 4);

  M5.Display.fillRect(bx + 19, mouthY + 35, 26, 48, plaque);
  M5.Display.drawRect(bx + 19, mouthY + 35, 26, 48, ink);
  M5.Display.drawRect(bx + 21, mouthY + 37, 22, 44, textGold);
  drawBucketSealText(bx + bw / 2, mouthY + 41);
  M5.Display.fillRect(bx + 8, mouthY + bh - 14, bw - 16, 5, woodDark);
}

void drawTempleNameLarge(const String& name, int32_t y) {
  M5.Display.setTextSize(2);
  int32_t width = M5.Display.textWidth(name);
  if (width <= 126) {
    M5.Display.drawCenterString(name, kCenterX, y);
    return;
  }
  M5.Display.setTextSize(1);
  M5.Display.drawCenterString(name, kCenterX, y + 6);
}

void drawMiniBucket() {
  int bx = 45;
  int by = 147;
  int bw = 46;
  int bh = 74;
  for (int i = 0; i < 9; ++i) {
    int sx = bx + 7 + i * 4;
    int top = by - 25 + (i % 3) * 2;
    M5.Display.fillRoundRect(sx, top, 4, 39, 2, (i % 2 == 0) ? woodLight : 0xb3a4);
  }
  M5.Display.fillRoundRect(bx, by, bw, bh, 10, wood);
  M5.Display.fillEllipse(bx + bw / 2, by, bw / 2, 8, woodLight);
  M5.Display.fillEllipse(bx + bw / 2, by, bw / 2 - 5, 5, 0x20a2);
  drawGreekBand(bx + 2, by + 13, bw - 4);
  drawGreekBand(bx + 2, by + bh - 16, bw - 4);
  M5.Display.fillRoundRect(bx + 12, by + 27, 22, 34, 5, woodDark);
  M5.Display.drawRoundRect(bx + 12, by + 27, 22, 34, 5, gold);
  M5.Display.setTextColor(paper);
  M5.Display.setTextSize(1);
  M5.Display.drawCenterString(isEn() ? "OMI" : isJa() ? "御籤" : "签文", bx + bw / 2, by + 35);
}

void drawTinyTorii(int32_t x, int32_t y) {
  M5.Display.fillRect(x + 2, y + 1, 19, 3, red);
  M5.Display.drawRect(x + 2, y + 1, 19, 3, ink);
  M5.Display.fillRect(x + 5, y + 7, 15, 4, woodLight);
  M5.Display.drawRect(x + 5, y + 7, 15, 4, ink);
  M5.Display.fillRect(x + 7, y + 11, 4, 15, red);
  M5.Display.fillRect(x + 16, y + 11, 4, 15, red);
  M5.Display.drawRect(x + 7, y + 11, 4, 15, ink);
  M5.Display.drawRect(x + 16, y + 11, 4, 15, ink);
  M5.Display.fillRect(x + 11, y + 15, 5, 3, buttonGold);
}

void drawOmamoriIcon(int32_t x, int32_t y) {
  M5.Display.fillRect(x + 4, y + 2, 14, 18, red);
  M5.Display.drawRect(x + 4, y + 2, 14, 18, ink);
  M5.Display.fillRect(x + 7, y, 8, 4, red);
  M5.Display.drawFastHLine(x + 7, y + 6, 8, textGold);
  M5.Display.setTextColor(card);
  M5.Display.setTextSize(1);
  M5.Display.drawCenterString(isEn() ? "LU" : "福", x + 11, y + 9);
}

void drawHome() {
  screen = ScreenState::Home;
  resetShakeBaseline();
  drawFortuneBucket(0, false);
  M5.Display.fillRect(0, 0, kScreenW, 40, paper);
  M5.Display.setTextColor(red);
  drawTempleNameLarge(sourceShortName(), 12);
  M5.Display.fillRect(108, 4, 25, 13, card);
  M5.Display.drawRect(108, 4, 25, 13, ink);
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(1);
  M5.Display.drawCenterString(languageCode(), 120, 6);

  M5.Display.fillRect(8, 42, 119, 38, card);
  M5.Display.drawRect(8, 42, 119, 38, ink);
  M5.Display.drawRect(10, 44, 115, 34, gold);
  M5.Display.setTextColor(red);
  M5.Display.setTextSize(2);
  M5.Display.drawCenterString(labelTodayLuck(), kCenterX, 49);

  M5.Display.fillRect(17, 202, kButtonW, kButtonH, buttonGold);
  M5.Display.drawRect(17, 202, kButtonW, kButtonH, ink);
  M5.Display.drawFastHLine(19, 204, kButtonW - 4, textGold);
  M5.Display.drawFastHLine(19, 224, kButtonW - 4, woodDark);
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(isEn() ? 2 : 1);
  M5.Display.drawCenterString(labelShake(), kCenterX, isEn() ? 205 : 208);
}

void drawShakeAnimation() {
  for (int i = 0; i < 10; ++i) {
    drawFortuneBucket((i % 2 == 0) ? -7 : 7, true);
    bucketRattleSound(i);
    M5.Display.setTextSize(1);
    M5.Display.setTextColor(red);
    M5.Display.drawCenterString(labelShaking(), kCenterX, 12);
    delay(105 + random(0, 36));
  }
}

uint8_t fortuneStars(const char* type, uint8_t salt = 0) {
  String t(type);
  uint8_t stars = 3;
  if (t == "大吉") stars = 5;
  else if (t == "吉") stars = 4;
  else if (t == "半吉" || t == "小吉") stars = 3;
  else if (t.indexOf("末") >= 0) stars = 2;
  else if (t == "凶") stars = 1;
  int adjusted = (int)stars + ((salt % 3) - 1);
  if (adjusted < 1) adjusted = 1;
  if (adjusted > 5) adjusted = 5;
  return adjusted;
}

String levelSummary(const char* type) {
  String t(type);
  if (isEn()) {
    if (t == "大吉") return "Excellent luck\nThings go well";
    if (t == "吉") return "Good luck\nSmooth progress";
    if (t == "半吉" || t == "小吉") return "Steady luck\nSmall gains";
    if (t.indexOf("末") >= 0) return "Slow first\nBetter later";
    return "Be careful\nAvoid risks";
  }
  if (isJa()) {
    if (t == "大吉") return "運勢最高\n万事順調";
    if (t == "吉") return "良い運勢\n物事順調";
    if (t == "半吉" || t == "小吉") return "穏やかな運\n小さな実り";
    if (t.indexOf("末") >= 0) return "先難後易\n後に開く";
    return "慎重第一\n危険を避ける";
  }
  if (t == "大吉") return "运势极佳\n万事顺遂";
  if (t == "吉") return "运势良好\n诸事顺利";
  if (t == "半吉" || t == "小吉") return "运势平稳\n有所收获";
  if (t.indexOf("末") >= 0) return "先难后易\n渐入佳境";
  return "多加谨慎\n防范风险";
}

void drawStars(int32_t x, int32_t y, uint8_t stars) {
  M5.Display.setTextSize(1);
  for (int i = 0; i < 5; ++i) {
    M5.Display.setTextColor(i < stars ? 0xeac0 : woodDark);
    M5.Display.drawString(i < stars ? "★" : "☆", x + i * 15, y);
  }
}

void drawToriiIcon(int32_t x, int32_t y) {
  M5.Display.fillRect(x + 4, y, 24, 4, ink);
  M5.Display.fillRect(x + 1, y + 4, 30, 4, red);
  M5.Display.drawRect(x + 1, y + 4, 30, 4, ink);
  M5.Display.fillRect(x + 6, y + 11, 22, 5, woodLight);
  M5.Display.drawRect(x + 6, y + 11, 22, 5, ink);
  M5.Display.fillRect(x + 9, y + 16, 5, 19, red);
  M5.Display.fillRect(x + 23, y + 16, 5, 19, red);
  M5.Display.drawRect(x + 9, y + 16, 5, 19, ink);
  M5.Display.drawRect(x + 23, y + 16, 5, 19, ink);
  M5.Display.fillRect(x + 14, y + 20, 9, 4, gold);
  M5.Display.drawFastHLine(x + 7, y + 35, 23, ink);
}

void drawDeviceCard(const String& title, const char* icon = "") {
  M5.Display.fillScreen(paper);
  M5.Display.drawRect(0, 0, kScreenW, kScreenH, ink);
  M5.Display.drawRect(2, 2, kScreenW - 4, kScreenH - 4, gold);
  M5.Display.fillRect(0, 0, kScreenW, 40, red);
  M5.Display.drawFastHLine(0, 40, kScreenW, ink);
  M5.Display.setTextColor(paper);
  if (String(icon).length() > 0) drawToriiIcon(8, 4);
  M5.Display.setTextSize(2); // about 24px title
  if (M5.Display.textWidth(title) > 96) {
    M5.Display.setTextSize(1);
    M5.Display.drawCenterString(title, kCenterX, 14);
  } else {
    M5.Display.drawCenterString(title, kCenterX + (String(icon).length() > 0 ? 12 : 0), 12);
  }
  M5.Display.fillRect(0, 207, kScreenW, 33, footer);
  M5.Display.drawFastHLine(0, 207, kScreenW, woodDark);
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(1); // about 14px subtitle/action
  M5.Display.drawCenterString(labelNextPage(), kCenterX, 215);
}

void drawVerticalLines(const String& text, int x, int y, int lineHeight);
void drawSummaryLines(const String& text, int32_t cx, int32_t y, int32_t w) {
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(1);
  int32_t lineY = y;
  String current;
  auto flushLine = [&]() {
    if (current.length() == 0) return;
    M5.Display.drawCenterString(current, cx, lineY);
    current = "";
    lineY += 17;
  };

  for (uint32_t i = 0; i < text.length();) {
    uint8_t c = text[i];
    uint8_t step = 1;
    if ((c & 0x80) == 0x00) step = 1;
    else if ((c & 0xE0) == 0xC0) step = 2;
    else if ((c & 0xF0) == 0xE0) step = 3;
    else if ((c & 0xF8) == 0xF0) step = 4;
    uint32_t end = min<uint32_t>(i + step, text.length());
    String piece = text.substring(i, end);
    if (piece == "\n") {
      flushLine();
      i = end;
      continue;
    }

    String next = current + piece;
    if (current.length() > 0 && M5.Display.textWidth(next) > w) {
      flushLine();
      next = piece;
    }
    current = next;
    i = end;
    if (lineY > 191) break;
  }
  flushLine();
}

void drawResultHome(const Fortune& f) {
  M5.Display.fillScreen(paper);
  M5.Display.drawRect(0, 0, kScreenW, kScreenH, ink);
  M5.Display.fillRect(0, 0, kScreenW, 40, red);
  M5.Display.drawFastHLine(0, 40, kScreenW, ink);
  drawToriiIcon(10, 3);
  M5.Display.setTextColor(paper);
  M5.Display.setTextSize(2); // 24px title
  M5.Display.drawCenterString(sourceShortName(), 84, 12);

  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(2); // 24px title
  M5.Display.drawCenterString(fortuneNoText(f.id), kCenterX, 58);

  uint16_t levelColor = fortuneLevelColor(f.type);
  String typeText = fortuneTypeLabel(f.type);
  M5.Display.fillRect(12, 86, 111, 56, levelColor);
  M5.Display.drawRect(12, 86, 111, 56, woodDark);
  M5.Display.setTextColor(levelColor == kichiColor ? ink : paper);
  M5.Display.setTextSize(4);
  int levelTextY = 90;
  if (M5.Display.textWidth(typeText) > 108) {
    M5.Display.setTextSize(3);
    levelTextY = 98;
  }
  M5.Display.drawCenterString(typeText, kCenterX, levelTextY);

  M5.Display.fillRect(10, 148, 115, 61, card);
  M5.Display.drawRect(10, 148, 115, 61, woodDark);
  M5.Display.drawRect(12, 150, 111, 57, gold);
  drawSummaryLines(levelSummary(f.type), kCenterX, 158, 105);

  M5.Display.fillRect(0, 214, kScreenW, 26, footer);
  M5.Display.drawFastHLine(0, 214, kScreenW, woodDark);
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(1); // 14px action
  M5.Display.drawCenterString(labelDetail(), kCenterX, 220);
}

void drawVerticalLines(const String& text, int x, int y, int lineHeight) {
  String s(text);
  int line = 0;
  String token;
  for (uint32_t i = 0; i < s.length() && line < 4;) {
    uint8_t c = s[i];
    uint8_t step = 1;
    if ((c & 0x80) == 0x00) step = 1;
    else if ((c & 0xE0) == 0xC0) step = 2;
    else if ((c & 0xF0) == 0xE0) step = 3;
    else if ((c & 0xF8) == 0xF0) step = 4;
    uint32_t end = min<uint32_t>(i + step, s.length());
    String piece = s.substring(i, end);
    if (piece == "\n") {
      M5.Display.drawCenterString(token, x, y + line * lineHeight);
      token = "";
      line++;
      i = end;
      continue;
    }
    token += piece;
    if (token.length() >= 12 || piece == "，" || piece == "。") {
      token.replace("，", "");
      token.replace("。", "");
      M5.Display.drawCenterString(token, x, y + line * lineHeight);
      token = "";
      line++;
    }
    i = end;
  }
  if (token.length() > 0 && line < 4) M5.Display.drawCenterString(token, x, y + line * lineHeight);
}

void drawReadyToReveal() {
  drawFortuneBucket(0, false);
  screen = ScreenState::ReadyToReveal;
  const Fortune& f = fortunes[pendingIndex];
  int sx = (kScreenW - kFortuneStickW) / 2;
  int sy = 45;
  M5.Display.fillRoundRect(sx, sy, kFortuneStickW, kFortuneStickH, 7, woodLight);
  M5.Display.drawRoundRect(sx, sy, kFortuneStickW, kFortuneStickH, 7, ink);
  M5.Display.drawFastVLine(sx + 4, sy + 8, kFortuneStickH - 14, gold);
  M5.Display.drawFastVLine(sx + kFortuneStickW - 2, sy + 8, kFortuneStickH - 14, woodDark);
  M5.Display.setTextColor(ink);
  M5.Display.setTextSize(1);
  M5.Display.drawCenterString(String(f.id), kCenterX, sy + 8);
  M5.Display.setTextSize(1);
  if (isEn()) {
    M5.Display.drawCenterString("NO", kCenterX, sy + 34);
    M5.Display.drawCenterString("LU", kCenterX, sy + 52);
  } else if (isJa()) {
    M5.Display.drawCenterString("番", kCenterX, sy + 31);
    M5.Display.drawCenterString("御", kCenterX, sy + 47);
    M5.Display.drawCenterString("籤", kCenterX, sy + 61);
  } else {
    M5.Display.drawCenterString("签", kCenterX, sy + 31);
    M5.Display.drawCenterString("文", kCenterX, sy + 47);
    M5.Display.drawCenterString("号", kCenterX, sy + 61);
  }
  M5.Display.setTextColor(ink);
  M5.Display.drawCenterString(labelReveal(), kCenterX, 218);
}

void drawFortunePage() {
  const Fortune& f = fortunes[currentIndex];
  if (page == 0) {
    screen = ScreenState::Poem;
    drawResultHome(f);
  } else if (page == 1) {
    drawDeviceCard(poemTitle(f.id));
    M5.Display.setTextColor(ink);
    M5.Display.setTextSize(1);
    drawWrapped(localizedPoem(f), 10, 60, 115, 18, ink);
  } else if (page == 2) {
    drawDeviceCard(readingTitle());
    M5.Display.setTextColor(ink);
    M5.Display.setTextSize(1);
    drawWrapped(localizedExplain(f), 10, 60, 115, 18, ink);
  } else if (page >= 3 && page <= 5) {
    screen = ScreenState::Detail;
    const char* title = page == 3 ? workTitle() : page == 4 ? moneyTitle() : loveTitle();
    String body = localizedDetail(f, page);
    drawDeviceCard(title);
    M5.Display.setTextColor(ink);
    M5.Display.setTextSize(1);
    drawWrapped(body, 10, 60, 115, 18, ink);
    drawStars(30, 160, fortuneStars(f.type, page));
  } else {
    screen = ScreenState::Detail;
    drawDeviceCard(overviewTitle());
    M5.Display.setTextColor(ink);
    M5.Display.setTextSize(1);
    int labelX = isEn() ? 8 : 14;
    int starX = isEn() ? 58 : 52;
    M5.Display.drawString(overviewLabel(0), labelX, 66); drawStars(starX, 66, fortuneStars(f.type, 3));
    M5.Display.drawString(overviewLabel(1), labelX, 86); drawStars(starX, 86, fortuneStars(f.type, 4));
    M5.Display.drawString(overviewLabel(2), labelX, 106); drawStars(starX, 106, fortuneStars(f.type, 5));
    M5.Display.drawString(overviewLabel(3), labelX, 126); drawStars(starX, 126, fortuneStars(f.type, 6));
    M5.Display.drawString(overviewLabel(4), labelX, 146); drawStars(starX, 146, fortuneStars(f.type, 7));
    M5.Display.setTextColor(red);
    M5.Display.drawCenterString(labelActToday(), kCenterX, 170);
  }
}

void startDrawRitual() {
  if (screen != ScreenState::Home || millis() - lastDrawMs < kShakeCooldownMs) return;
  lastDrawMs = millis();
  drawShakeAnimation();
  pendingIndex = random(0, kFortuneCount);
  drawReadyToReveal();
}

void revealFortune() {
  if (screen != ScreenState::ReadyToReveal) return;
  revealSound();
  currentIndex = pendingIndex;
  page = 0;
  drawFortunePage();
}

void handleShake() {
  if (screen != ScreenState::Home) {
    resetShakeBaseline();
    return;
  }
  auto updated = M5.Imu.update();
  if (!updated) return;
  auto imu = M5.Imu.getImuData();
  float accelDelta = abs(imu.accel.x - lastAx) + abs(imu.accel.y - lastAy) + abs(imu.accel.z - lastAz);
  float gyroPower = abs(imu.gyro.x) + abs(imu.gyro.y) + abs(imu.gyro.z);
  lastAx = imu.accel.x;
  lastAy = imu.accel.y;
  lastAz = imu.accel.z;
  if ((accelDelta > 0.9f || gyroPower > 230.0f) && millis() - lastDrawMs > kShakeCooldownMs) {
    startDrawRitual();
  }
}

void nextSource() {
  if (screen != ScreenState::Home) return;
  currentSource = (currentSource + 1) % kSourceCount;
  drawHome();
}

void nextLanguage() {
  if (screen != ScreenState::Home) return;
  if (currentLanguage == Language::Zh) currentLanguage = Language::Ja;
  else if (currentLanguage == Language::Ja) currentLanguage = Language::En;
  else currentLanguage = Language::Zh;
  applyLanguageFont();
  tickSound(1180, 80);
  drawHome();
}
}  // namespace

void setup() {
  M5.begin();
  M5.Display.setRotation(0);
  applyLanguageFont();
  M5.Display.setBrightness(180);
  setupSpeaker();
  randomSeed(esp_random());
  drawHome();
}

void loop() {
  M5.update();
  handleShake();

  if (M5.BtnA.wasClicked()) {
    if (screen == ScreenState::Home) {
      nextSource();
    } else if (screen == ScreenState::ReadyToReveal) {
      revealFortune();
    } else {
      page = (page + 1) % 7;
      drawFortunePage();
    }
  }

  if (M5.BtnB.wasClicked()) {
    if (screen == ScreenState::Home) {
      nextLanguage();
    } else {
      drawHome();
    }
  }

  delay(20);
}
